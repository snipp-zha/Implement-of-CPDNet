import torch
if __name__ == '__main__':
    model_pth = 'D:/HZX/Program files/cache/1761170395/FileRecv/leo_segmentation/Industrial_defect_12_labeled/self_train/20230903-231730-FCN/the_best_model_1599_0.1500.pth'
    net = torch.load(model_pth, map_location=torch.device('cpu'))
    for key, value in net["state_dict"].items():
        print(key,value.size(),sep="  ")

