#%%
from PIL import Image
import matplotlib.pyplot as plt
import torch
import numpy as np
import pytorch_wavelets as pw

J = 1
path = '/opt/data/private/磁瓦缺陷数据集/MT_Fray/Imgs/exp1_num_77531.jpg'
img = np.array(Image.open(path), dtype='float32') / 255 # (512,512)
img = torch.from_numpy(img).unsqueeze(0).unsqueeze(0)
# print(img.shape)
xfm = pw.DWTForward(J=J, wave='haar', mode='symmetric')
ifm = pw.DWTInverse(wave='haar', mode='symmetric')
subbands = xfm(img) # tuple first is original image, the second one is edge information
# print(type(subbands[0]))
# print(type(subbands[1][0])) #list
# print(subbands[1][0].shape) # list
plt.figure(dpi = 200)
plt.subplot(221)
plt.imshow(subbands[0][0][0],cmap='gray')
plt.subplot(222)
plt.imshow(subbands[1][0][:,:,0,][0][0],cmap='gray')
plt.subplot(223)
plt.imshow(subbands[1][0][:,:,1,][0][0],cmap='gray')
plt.subplot(224)
plt.imshow(subbands[1][0][:,:,2,][0][0],cmap='gray')
plt.show()
# temp = torch.cat((subbands[1][0][:,:,0,].unsqueeze(2),subbands[1][0][:,:,1,].unsqueeze(2),subbands[1][0][:,:,2,].unsqueeze(2)),2)
# # print('temp',temp.shape) # (1,1,3,256,256)
# # a= list(temp)
# # print(type(a))
# # print(a[0].shape)
# b = []
# b.append(temp)
# # print(type(b))
# # print(b[0].shape)
# # print(b[1][0].shape)
# zhongjian = (subbands[0],b)
# wave_inver = ifm(zhongjian) # (1,1,512,512)
# # print(wave_inver.shape)
# # plt.figure(dpi = 200)
# # plt.subplot(131)
# plt.imshow(wave_inver[0][0], cmap='gray')
# # plt.subplot(132)
# # plt.imshow(wave_inver[0][0], cmap='gray')

# # plt.subplot(131)
# # plt.imshow(img[0][0], cmap='gray')
# # plt.subplot(133)
# # plt.imshow(img[0][0] - wave_inver[0][0], cmap='gray')
# plt.show()

# %%
import torch
# a = torch.ones((1,1,3,256,256))
# b = []
# b.append(a)
# print(b[0].shape)
from PIL import Image
import matplotlib.pyplot as plt
import torch
import cv2
import numpy as np
import pytorch_wavelets as pw
import matplotlib.pyplot as plt
path ='/opt/data/private/磁瓦缺陷数据集/MT_Break/Imgs/exp1_num_26106.jpg'
img = np.array(Image.open(path), dtype='float32') 
img = cv2.resize(img, (512,512), interpolation=cv2.INTER_AREA) 
img = np.flip(img, axis=1).copy()
# print(np.min(img),np.max(img))
# print(np.unique((img)))
# temp = img
# temp[temp>128]=255
# print(np.unique((temp)))
# plt.subplot(121)
# plt.imshow(img, cmap='gray')
# plt.subplot(122)
# plt.imshow(temp, cmap='gray')
print(img.shape) # (376, 491) (290, 113) (309, 513)
plt.imshow(img, cmap='gray')
plt.show()
# %%
import torch
import numpy as np
import pytorch_wavelets as pw
J = 1

img = torch.ones((16,1,256,256))
xfm = pw.DWTForward(J=J, wave='haar', mode='symmetric')
ifm = pw.DWTInverse(wave='haar', mode='symmetric')
subbands = xfm(img) # tuple first is original image, the second one is edge information
wave_inver = ifm(subbands) # (1,1,512,512)
print(wave_inver.shape)
# %%
from torch.nn import functional as F
import torch.nn as nn
from PIL import Image
import numpy as np
import torch
import cv2
import matplotlib.pyplot as plt
def upfirdn2d_native(
    input, kernel, up_x, up_y, down_x, down_y, pad_x0, pad_x1, pad_y0, pad_y1
):
    _, minor, in_h, in_w = input.shape
    kernel_h, kernel_w = kernel.shape

    out = input.view(-1, minor, in_h, 1, in_w, 1)
    out = F.pad(out, [0, up_x - 1, 0, 0, 0, up_y - 1, 0, 0])
    out = out.view(-1, minor, in_h * up_y, in_w * up_x)

    out = F.pad(
        out, [max(pad_x0, 0), max(pad_x1, 0), max(pad_y0, 0), max(pad_y1, 0)]
    )
    out = out[
        :,
        :,
        max(-pad_y0, 0): out.shape[2] - max(-pad_y1, 0),
        max(-pad_x0, 0): out.shape[3] - max(-pad_x1, 0),
    ]

    # out = out.permute(0, 3, 1, 2)
    out = out.reshape(
        [-1, 1, in_h * up_y + pad_y0 + pad_y1, in_w * up_x + pad_x0 + pad_x1]
    )
    w = torch.flip(kernel, [0, 1]).view(1, 1, kernel_h, kernel_w)
    out = F.conv2d(out, w)
    out = out.reshape(
        -1,
        minor,
        in_h * up_y + pad_y0 + pad_y1 - kernel_h + 1,
        in_w * up_x + pad_x0 + pad_x1 - kernel_w + 1,
    )
    # out = out.permute(0, 2, 3, 1)

    return out[:, :, ::down_y, ::down_x]

def get_haar_wavelet(in_channels):
    haar_wav_l = 1 / (2 ** 0.5) * torch.ones(1, 2)
    haar_wav_h = 1 / (2 ** 0.5) * torch.ones(1, 2)
    haar_wav_h[0, 0] = -1 * haar_wav_h[0, 0]

    haar_wav_ll = haar_wav_l.T * haar_wav_l
    haar_wav_lh = haar_wav_h.T * haar_wav_l
    haar_wav_hl = haar_wav_l.T * haar_wav_h
    haar_wav_hh = haar_wav_h.T * haar_wav_h

    return haar_wav_ll, haar_wav_lh, haar_wav_hl, haar_wav_hh

def upfirdn2d(input, kernel, up=1, down=1, pad=(0, 0)):
    return upfirdn2d_native(input, kernel, up, up, down, down, pad[0], pad[1], pad[0], pad[1])

class HaarTransform(nn.Module):
    def __init__(self, in_channels=1,four_channels = True,levels =1):
        super().__init__()


        ll, lh, hl, hh = get_haar_wavelet(in_channels)

        self.register_buffer('ll', ll)
        self.register_buffer('lh', lh)
        self.register_buffer('hl', hl)
        self.register_buffer('hh', hh)
        self.four_channels = four_channels

        if levels > 1 and not four_channels :
            self.next_level = HaarTransform(in_channels,four_channels,levels-1)
        else :
            self.next_level = None

    def forward(self, input):

        ll = upfirdn2d(input, self.ll, down=2)
        lh = upfirdn2d(input, self.lh, down=2)
        hl = upfirdn2d(input, self.hl, down=2)
        hh = upfirdn2d(input, self.hh, down=2)

        if self.next_level != None :
            ll = self.next_level(ll)

        if self.four_channels :
            print(111111111)
            return torch.cat((ll, lh, hl, hh), 1)
        else :
            print(222222)
            return torch.cat((torch.cat((ll,lh),-2),torch.cat((hl,hh),-2)),-1)
        
class InverseHaarTransform(nn.Module):
    def __init__(self, in_channels,four_channels = True,levels = 1):
        super().__init__()

        ll, lh, hl, hh = get_haar_wavelet(in_channels)

        self.register_buffer('ll', ll)
        self.register_buffer('lh', -lh)
        self.register_buffer('hl', -hl)
        self.register_buffer('hh', hh)

        self.four_channels = four_channels

        if levels > 1 and not four_channels :
            self.next_level = InverseHaarTransform(in_channels,four_channels,levels-1)
        else :
            self.next_level = None

    def forward(self, input):
        if self.four_channels :
            ll, lh, hl, hh = input.chunk(4, 1)
        else :
            toprow,bottomrow = input.chunk(2,-1)
            ll,lh = toprow.chunk(2,-2)
            hl,hh = bottomrow.chunk(2,-2)

        if self.next_level != None :
            ll = self.next_level(ll)

        ll = upfirdn2d(ll, self.ll, up=2, pad=(1, 0, 1, 0))
        lh = upfirdn2d(lh, self.lh, up=2, pad=(1, 0, 1, 0))
        hl = upfirdn2d(hl, self.hl, up=2, pad=(1, 0, 1, 0))
        hh = upfirdn2d(hh, self.hh, up=2, pad=(1, 0, 1, 0))

        return ll + lh + hl + hh        
path = '/opt/data/private/磁瓦缺陷数据集/MT_Fray/Imgs/exp1_num_77531.jpg'
img = np.array(Image.open(path), dtype='float32') / 255 # (512,512)
img = cv2.resize(img, (600,232), interpolation=cv2.INTER_AREA) 
img = torch.from_numpy(img).unsqueeze(0).unsqueeze(0)
dwt = HaarTransform(1) # 输入通道数
iwt = InverseHaarTransform(4)
wavelet_image = dwt(img)
print(img.shape)
print(wavelet_image.shape)
inverwavelet_image = iwt(wavelet_image)
print(inverwavelet_image.shape)
plt.figure(dpi=200)
plt.subplot(131)
plt.imshow(img[0][0], cmap='gray')
plt.subplot(132)
plt.imshow(inverwavelet_image[0][0], cmap='gray')
plt.subplot(133)
plt.imshow(inverwavelet_image[0][0]-img[0][0], cmap='gray')
print(torch.min(inverwavelet_image[0][0]-img[0][0]), torch.max(inverwavelet_image[0][0]-img[0][0]))
plt.show()
# plt.subplot(221)
# plt.imshow(wavelet_image[0][0], cmap='gray')
# plt.subplot(222)
# plt.imshow(wavelet_image[0][1], cmap='gray')
# plt.subplot(223)
# plt.imshow(wavelet_image[0][2], cmap='gray')
# plt.subplot(224)
# plt.imshow(wavelet_image[0][3], cmap='gray')
# plt.show()

# %%
import numpy as np
from PIL import Image
import cv2
import matplotlib.pyplot as plt
path = '/opt/data/private/磁瓦缺陷数据集/MT_Fray/Imgs/exp1_num_77531.jpg'
image = np.array(Image.open(path), dtype='float32') / 255 # (512,512)
image = cv2.resize(image, (512,512), interpolation=cv2.INTER_AREA) 
# image = np.rot90(image, 3)
# label = np.rot90(label, k)
# axis = np.random.randint(0, 2)
image = np.flip(image, axis=1).copy()
plt.imshow(image,cmap='gray')
plt.show()
# %%
