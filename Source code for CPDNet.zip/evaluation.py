import random
import torch
import torch.nn as nn
#from model import U_Net
from torch.utils.data import DataLoader
from dataloaders.dataset import Defect
from dataset import Dataset, TwoStreamBatchSampler
import glob
from sklearn.model_selection import train_test_split
from dataloaders.dataset import *
import torch.nn.functional as F
from skimage.measure import label
import cv2
from deeplabv3 import build_model
#from Models import *
import numpy as np
from model import *
from PIL import Image
import matplotlib.pyplot as plt


class Evaluator(object):
    def __init__(self, num_class):
        self.num_class = num_class
        self.confusion_matrix = np.zeros((self.num_class,)*2)

    def Pixel_Accuracy(self):
        # acc = (TP + TN) / (TP + TN + FP + TN)
        Acc = np.diag(self.confusion_matrix).sum() / \
            self.confusion_matrix.sum()
        return Acc

    def Pixel_Accuracy_Class(self):
        # acc = (TP) / TP + FP
        Acc = np.diag(self.confusion_matrix) / \
            self.confusion_matrix.sum(axis=1)
        Acc_class = np.nanmean(Acc)
        return Acc_class

    def Mean_Intersection_over_Union(self):
        MIoU = np.diag(self.confusion_matrix) / (
            np.sum(self.confusion_matrix, axis=1) + np.sum(self.confusion_matrix, axis=0) -
            np.diag(self.confusion_matrix))
        MIoU = np.nanmean(MIoU)
        return MIoU

    def Frequency_Weighted_Intersection_over_Union(self):
        # FWIOU =     [(TP+FN)/(TP+FP+TN+FN)] *[TP / (TP + FP + FN)]
        freq = np.sum(self.confusion_matrix, axis=1) / \
            np.sum(self.confusion_matrix)
        iu = np.diag(self.confusion_matrix) / (
            np.sum(self.confusion_matrix, axis=1) + np.sum(self.confusion_matrix, axis=0) -
            np.diag(self.confusion_matrix))

        FWIoU = (freq[freq > 0] * iu[freq > 0]).sum()
        return FWIoU

    def _generate_matrix(self, gt_image, pre_image):
        mask = (gt_image >= 0) & (gt_image < self.num_class)
        label = self.num_class * gt_image[mask].astype('int64') + pre_image[mask].astype('int64')
        count = np.bincount(label, minlength=self.num_class**2)
        confusion_matrix = count.reshape(self.num_class, self.num_class)
        return confusion_matrix

    def add_batch(self, gt_image, pre_image):
        assert gt_image.shape == pre_image.shape
        self.confusion_matrix += self._generate_matrix(gt_image, pre_image)

    def reset(self):
        self.confusion_matrix = np.zeros((self.num_class,) * 2)

def measure_pa_miou(num_class, pre_image, gt_image):
    pre_image = get_cut_mask(pre_image, nms=1)
    pre_image = pre_image.cpu().numpy()
    gt_image = gt_image.cpu().numpy()
    metric = Evaluator(num_class)
    metric.add_batch(gt_image, pre_image)
    mIoU = metric.Mean_Intersection_over_Union()
    return mIoU

def worker_init_fn(worker_id):
    random.seed(1337+worker_id)

def get_cut_mask(out, thres=0.5, nms=0):
    probs = F.sigmoid(out)
    mask = (probs >= thres).type(torch.int64) # [2, 144, 240, 240]
    mask = mask.contiguous()
    if nms == 1:
        mask = LargestCC_pancreas(mask)
    return mask

def LargestCC_pancreas(segmentation):
    N = segmentation.shape[0]
    batch_list = []
    for n in range(N):
        n_prob = segmentation[n].detach().cpu().numpy()
        labels = label(n_prob)
        if labels.max() != 0:
            largestCC = labels == np.argmax(np.bincount(labels.flat)[1:])+1
        else:
            largestCC = n_prob
        batch_list.append(largestCC)
    
    return torch.Tensor(batch_list).cuda()

def numeric_score(prediction, groundtruth):
    """Computes scores:
    FP = False Positives
    FN = False Negatives
    TP = True Positives
    TN = True Negatives
    return: FP, FN, TP, TN"""

    FP = torch.sum((prediction == 1) & (groundtruth == 0))
    FN = torch.sum((prediction == 0) & (groundtruth == 1))
    TP = torch.sum((prediction == 1) & (groundtruth == 1))
    TN = torch.sum((prediction == 0) & (groundtruth == 0))

    return FP, FN, TP, TN
    
def accuracy_score(prediction, groundtruth):
    """Getting the accuracy of the model"""
    prediction = get_cut_mask(prediction, nms=1)
    groundtruth = groundtruth > 0.5
    FP, FN, TP, TN = numeric_score(prediction, groundtruth)
    N = FP + FN + TP + TN
    smooth = 1e-6
    accuracy = (TP + TN + smooth)/ (N + smooth)
    recall = (TP + smooth)/(TP + FN + smooth)
    precision = (TP + smooth)/(TP + FP + smooth)
    iou = (TP + smooth)/(FN + TP + FP + smooth)
    dice = (2*TP + smooth)/(FN + 2*TP + FP + smooth)
    F1 = 2*recall*precision/(recall+precision)
    return accuracy, recall, precision, F1, iou, dice

def load_net(net, path):
    state = torch.load(str(path),map_location='cpu')
    net.load_state_dict(state['state_dict'])

device = 'cuda' if torch.cuda.is_available() else 'cpu'
overall_dataset = [file_path for file_path in glob.glob('D:/HZX/Program files/cache/1761170395/FileRecv/磁瓦缺陷数据集/磁瓦缺陷数据集/MT_Blowhole/Imgs/*.jpg')]
train_data_path, val_data_path = train_test_split(overall_dataset, test_size=0.2, random_state=42) 
valset = Defect(base_dir=val_data_path,
                    split='val',
                    transform = ToTensor())    
valloader = DataLoader(valset, batch_size=1, shuffle=False, num_workers=0, pin_memory=True, worker_init_fn=worker_init_fn)

model = U_Net(1)
#model = FCN(1)
#model = AttU_Net(1)
#model = ResU_Net(1)
#model = build_model('Deeplabv3plus_res50', 1, 'resnet34', pretrained=True, out_stride=16, mult_grid=False)
#model = NestedUNet(1)
pretrained_model = 'D:/HZX/Program files/cache/1761170395/FileRecv/Diffusion-based-Segmentation/results/savedmodel000000.pt'
load_net(model, pretrained_model)

model = model.to(device)

with torch.no_grad():
    model.eval()

    acc_val_all = 0
    recall_val_all = 0
    precision_val_all = 0
    F1_val_all = 0
    iou_val_all = 0
    dice_val_all = 0
    miou_val_all = 0

    for step, sampled_batch in enumerate(valloader):
        volume_batch, label_batch = sampled_batch['image'], sampled_batch['label']
        volume_batch, label_batch = volume_batch.to(device), label_batch.to(device)
        outputs = model(volume_batch)
        accuracy, recall, precision, F1, iou, dice = accuracy_score(outputs, label_batch)
        miou = measure_pa_miou(2, outputs, label_batch)

        acc_val_all += accuracy.item()
        recall_val_all += recall.item()
        precision_val_all += precision.item()
        F1_val_all += F1.item()
        iou_val_all += iou.item()
        dice_val_all += dice.item()
        miou_val_all += miou.item()

    acc_val_avg =  acc_val_all / len(valloader) 
    recall_val_avg =  recall_val_all / len(valloader)  
    precision_val_avg =  precision_val_all / len(valloader)  
    F1_val_avg =  F1_val_all / len(valloader)  
    iou_val_avg =  iou_val_all / len(valloader)  
    dice_val_avg =  dice_val_all / len(valloader)
    miou_val_avg = miou_val_all / len(valloader)
    print('accuracy: %.4f, recall: %.4f, precision: %.4f, F1: %.4f, iou: %.4f, dice: %.4f, miou: %.4f'% (acc_val_avg, recall_val_avg, precision_val_avg, F1_val_avg, iou_val_avg, dice_val_avg,miou_val_avg))
